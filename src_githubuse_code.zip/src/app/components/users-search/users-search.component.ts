import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NgModule } from '@angular/core';
import { GithubService } from 'src/app/services/github.service';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-users-search',
  templateUrl: './users-search.component.html',
  styleUrls: ['./users-search.component.css']
})
export class UsersSearchComponent implements OnInit {

  public userName;
  public errorMessage;
  @Output() searchedUser: any = new EventEmitter();

  constructor(private gitusersService: GithubService) { }

  ngOnInit() {
  }

  // Function to search user
  searchUser(event) {
    this.userName = '';
    this.userName = event.target.value;
    if (event.target.value) {
      this.gitusersService.getSearchUser(this.userName).subscribe((userList: User[]) => {
        this.searchedUser.emit(userList);
      }, error => this.errorMessage = error);
    } else {
      this.errorMessage = '';
      this.searchedUser.emit(this.errorMessage);
    }
  }

}
