import { Component, OnInit, Input } from '@angular/core';
import { GithubService } from '../../services/github.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {

  public errorMessage;
  public userList: any;
  public reposdata: any;


  constructor(private gitusersService: GithubService, public dialog: MatDialog) { }

  ngOnInit() {
    // Get all users list
    this.gitusersService.getUser()
      .subscribe(data => {
        this.userList = data;
      }, error => this.errorMessage = error);
  }


  // Function to display searched user
  searchedUserData(event) {
    if (event) {       // if there is input display searched user
      this.userList = [
        {
          login: event.login,
          avatar_url: event.avatar_url
        }
      ];
    } else {
      this.gitusersService.getUser() // if there is no input display all users
        .subscribe(data => {
          this.userList = data;
        }, error => this.errorMessage = error);
    }
  }
}
