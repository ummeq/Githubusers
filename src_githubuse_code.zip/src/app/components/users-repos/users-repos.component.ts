import { Component, OnInit, OnChanges, Input, Output, EventEmitter, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { GithubService } from '../../services/github.service';
import { RepositoryListModalComponent } from '../repository-list-modal/repository-list-modal.component';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-users-repos',
  templateUrl: './users-repos.component.html',
  styleUrls: ['./users-repos.component.css']
})
export class UsersReposComponent implements OnInit {

  @Input() userlist: any;
  public reposList: any;
  public userReposData = [];
  public show = false;
  public showButton = true;
  public errorMessage;
  constructor(private gitusersService: GithubService,
              public dialogRef: MatDialogRef<UsersReposComponent>,
              public dialog: MatDialog) { }

  ngOnInit() {
  }

  // Function to get repository 
  getUserRepos() {
    this.gitusersService.getRepos(this.userlist.login).subscribe((userList: User[]) => {
      userList.forEach((repos) => {
        this.userReposData.push(repos);
      });
      this.dialog.open(RepositoryListModalComponent, { // Open Dailog 
        height: '400px',
        width: '600px',
        data: {
          repoDetails: this.userReposData, // Passing Data to Dailog
          username: this.userlist.login
        }
      });
    });
  }

  // Option function to hide dailog
  onNoClick() {
    this.dialogRef.close();
  }

}
