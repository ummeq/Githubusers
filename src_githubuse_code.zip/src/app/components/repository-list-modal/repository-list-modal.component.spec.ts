import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RepositoryListModalComponent } from './repository-list-modal.component';

describe('RepositoryListModalComponent', () => {
  let component: RepositoryListModalComponent;
  let fixture: ComponentFixture<RepositoryListModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RepositoryListModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RepositoryListModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
