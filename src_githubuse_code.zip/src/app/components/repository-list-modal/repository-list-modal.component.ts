import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA} from '@angular/material/dialog';
@Component({
  selector: 'app-repository-list-modal',
  templateUrl: './repository-list-modal.component.html',
  styleUrls: ['./repository-list-modal.component.css']
})
export class RepositoryListModalComponent implements OnInit {

  // To get data from another component we have to inject MAt_DIALOG
  constructor(@Inject(MAT_DIALOG_DATA) public data: any)  { }

  ngOnInit() {
  }

}
