export class User {
    public login?: string;
    public id?: string;
    public avatarUrl?: string;
    public url?: string;
    public followersUrl?: string;
    public email?: string;
    public followers?: User[];


}