import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { map, catchError } from 'rxjs/operators';
import { Observable, pipe } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GithubService {

  private username = 'ummeq';
  private clientId = '18ba8896be8d62bdfe5a';
  private clientSecret = '4d5af400f2e74835cfb20af20b6010cc520d7f5b';

  constructor(private http: HttpClient) {
    console.log('Github Service Init...');
  }

  getUser(): Observable<User[]> {
    return this.http.get
      ('https://api.github.com/users?since=135; rel="next"')
      .pipe(map(res => res as User[]));
  }


  getRepos(username): Observable<User[]> {
    return this.http.get('https://api.github.com/users/' + username + '/repos')
      .pipe(map(res => res as User[]));
  }

  getSearchUser(username): Observable<User[]> {
    return this
            .http
            .get('https://api.github.com/users/' + username + '?client_id=' + this.clientId + ' &client_secret = '+ this.clientSecret )
      .pipe(map(res => res as User[]));
  }



}
