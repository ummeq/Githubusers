import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 
import { UsersListComponent } from './components/users-list/users-list.component';
import { UsersReposComponent } from './components/users-repos/users-repos.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule, MatFormFieldModule, 
        MatButtonModule, MatInputModule, MAT_DIALOG_DEFAULT_OPTIONS, MAT_DIALOG_DATA, 
        MatDialogRef, MatIconModule } from '@angular/material';
import { RepositoryListModalComponent } from './components/repository-list-modal/repository-list-modal.component';
import { UsersSearchComponent } from './components/users-search/users-search.component';

@NgModule({
  declarations: [
    AppComponent,
    UsersListComponent,
    UsersReposComponent,
    RepositoryListModalComponent,
    UsersSearchComponent
  ],
  entryComponents: [RepositoryListModalComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatDialogModule,
    MatIconModule,
    MatFormFieldModule,
    MatButtonModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [{provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: {hasBackdrop: true, direction: 'ltr'}},
    { provide: MatDialogRef, useValue: {} },
    { provide: MAT_DIALOG_DATA, useValue: [] }],
  bootstrap: [AppComponent]

})
export class AppModule { }
